#!/bin/bash
# Verification pass of the camera-ready run. Not part of the artifact (untracked).
# Re-measures the timing stages into build/verify/, leaving the main stores
# untouched, so that cells disturbed during the main run show up when the two
# passes are compared. Re-Pair is left out. Everything goes to verify.log.
cd "$(dirname "$0")" || exit 1
exec 9>.run.lock
flock -n 9 || { echo "A run is already in progress here; see run.log / verify.log."; exit 1; }
V=build/verify
VPY=.venv/bin/python
mkdir -p "$V"
colargs=()
for c in dbpedia/abstract msmarco_urls/url msmarco_queries/query amazon/titles tpch/p_name tpch/c_comment; do
  colargs+=(--column "$c=datasets/materialized/$c.col")
done
step() {
  local name=$1; shift
  echo "=== $name START $(date -Is)"
  if PIN_CPUS=1 PYTHONPATH=. PYTHONHASHSEED=0 taskset -c 1 "$@"; then
    echo "=== $name OK $(date -Is)"
  else
    echo "=== $name FAILED $(date -Is)"
  fi
}
{
# the threshold the artifact's grid lacks (ratios only); goes into the main store
step a1-T10 $VPY -m experiments.a1_driver --datasets-manifest experiments/datasets.yaml \
     --a1-cells $V/a1_T10_cells.yaml --columns-dir datasets/materialized \
     --db build/a1_results.sqlite --runner-path build/runners/onpair/onpair_runner
step headline $VPY -m orchestrator.orchestrate --build-root build \
     --cells build/headline_cells.yaml --modes experiments/baseline_modes.yaml \
     --needles testdata/g6_needles.txt --db $V/results.sqlite --csv $V/results.csv \
     --manifest $V/manifest.json --workdir $V/headline_workdir
step decode $VPY -m experiments.decode_driver "${colargs[@]}" \
     --workdir $V/decode --out-json $V/decode/results.json \
     --out-csv $V/decode/observations.csv
step dictorder $VPY -m experiments.dictionary_order_diagnostic_driver "${colargs[@]}" \
     --wire-root $V/decode --workdir $V/dictorder \
     --samples 11 --warmups 2
step access $VPY -m experiments.ra_headline_driver --skip repair \
     --db $V/ra_headline_results.sqlite
step a5 $VPY -m experiments.a5_driver --datasets-manifest experiments/datasets.yaml \
     --a5-cells experiments/a5_cells.yaml --columns-dir datasets/materialized \
     --db $V/a5_results.sqlite --build-root build
step a6 $VPY -m experiments.a6_driver --datasets-manifest experiments/datasets.yaml \
     --a6-cells experiments/a6_cells.yaml --columns-dir datasets/materialized \
     --db $V/a6_results.sqlite --build-root build
step a4 $VPY -m experiments.a4_driver --datasets-manifest experiments/datasets.yaml \
     --a4-cells experiments/a4_cells.yaml --columns-dir datasets/materialized \
     --db $V/a4_results.sqlite --runner-path build/runners/onpair/onpair_runner
# Re-Pair is cut short here (5 minutes per size); only OnPair's numbers matter
step scale $VPY -m experiments.nsweep_driver --db $V/nsweep_results.sqlite --op-timeout-s 300
} 2>&1 | tee -a verify.log
echo "=== verify finished $(date -Is)" | tee -a verify.log
