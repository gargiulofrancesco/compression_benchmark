#!/bin/bash
# Re-measures Re-Pair's point-access cells after its access index moved to
# 32-bit positions (commit 643d0c7). Not part of the artifact (untracked).
# Separate store: build/repair_ra32/. Log: repair_ra32.log.
cd "$(dirname "$0")" || exit 1
exec 9>.run.lock
flock -n 9 || { echo "A run is already in progress here; see the logs."; exit 1; }
V=build/repair_ra32
mkdir -p "$V"
hw() { echo "    hw: no_turbo=$(cat /sys/devices/system/cpu/intel_pstate/no_turbo) governor=$(cat /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor) throttle_core=$(cat /sys/devices/system/cpu/cpu1/thermal_throttle/core_throttle_count) load=$(cut -d' ' -f1-3 /proc/loadavg)"; }
{
echo "=== repair-access START $(date -Is)"; hw
if PIN_CPUS=1 PYTHONPATH=. taskset -c 1 .venv/bin/python -m experiments.ra_headline_driver \
     --only repair --cheap-first --db $V/ra_headline_results.sqlite; then
  echo "=== repair-access OK $(date -Is)"
else
  echo "=== repair-access FAILED $(date -Is)"
fi
hw
} 2>&1 | tee -a repair_ra32.log
echo "=== repair_ra32 finished $(date -Is)" | tee -a repair_ra32.log
