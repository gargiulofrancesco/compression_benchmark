#!/bin/bash
# Camera-ready measurement run. Not part of the artifact (untracked).
# Runs the timing stages one after the other, each pinned to CPU 1; a stage
# that fails is reported and the run carries on. Everything goes to run.log.
#
#   ./run.sh                 all stages, in the order below
#   ./run.sh scale repair    only the named stages
cd "$(dirname "$0")" || exit 1
exec 9>.run.lock
flock -n 9 || { echo "A run is already in progress here; see run.log."; exit 1; }

stages=("$@")
[ ${#stages[@]} -eq 0 ] && stages=(headline access decode dictorder bpedecoder
                                   prefix finalize ablations modelsize synthetic
                                   scale repair)
for s in "${stages[@]}"; do
  echo "=== $s START $(date -Is)"
  if PIN_CPUS=1 taskset -c 1 ./reproduce.sh "$s"; then
    echo "=== $s OK $(date -Is)"
  else
    echo "=== $s FAILED $(date -Is)"
  fi
done 2>&1 | tee -a run.log
echo "=== run finished $(date -Is)" | tee -a run.log
