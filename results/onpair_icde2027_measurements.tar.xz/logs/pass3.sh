#!/bin/bash
# Third pass of the camera-ready run. Not part of the artifact (untracked).
# Same stages and options as verify.sh, into build/pass3/, so that every cell
# has three independent passes. Logs the hardware state at every stage and
# samples it every 10 s (pass3_monitor.log). Everything else goes to pass3.log.
cd "$(dirname "$0")" || exit 1
exec 9>.run.lock
flock -n 9 || { echo "A run is already in progress here; see the logs."; exit 1; }
V=build/pass3
VPY=.venv/bin/python
mkdir -p "$V"
CPUFREQ=/sys/devices/system/cpu/cpu1/cpufreq
THR=/sys/devices/system/cpu/cpu1/thermal_throttle
ZONE=$(for z in /sys/class/thermal/thermal_zone*; do [ "$(cat $z/type)" = x86_pkg_temp ] && echo $z; done | head -1)
hw() {
  echo "    hw: no_turbo=$(cat /sys/devices/system/cpu/intel_pstate/no_turbo)" \
       "governor=$(cat $CPUFREQ/scaling_governor) max_khz=$(cat $CPUFREQ/scaling_max_freq)" \
       "throttle_core=$(cat $THR/core_throttle_count) throttle_pkg=$(cat $THR/package_throttle_count)" \
       "pkg_temp_c=$(( $(cat $ZONE/temp) / 1000 )) load=$(cut -d' ' -f1-3 /proc/loadavg)"
}
# every 10 s, from an efficiency core: time, CPU 1 frequency (kHz), throttle
# counters, package temperature (mC), 1-minute load, running/total tasks, no_turbo
( exec 9>&-
  exec taskset -c 19 bash -c "while :; do echo \"\$(date +%s) \$(cat $CPUFREQ/scaling_cur_freq) \$(cat $THR/core_throttle_count) \$(cat $THR/package_throttle_count) \$(cat $ZONE/temp) \$(cut -d' ' -f1,4 /proc/loadavg) \$(cat /sys/devices/system/cpu/intel_pstate/no_turbo)\"; sleep 10; done" ) >> pass3_monitor.log &
MON=$!
trap 'kill $MON 2>/dev/null' EXIT
colargs=()
for c in dbpedia/abstract msmarco_urls/url msmarco_queries/query amazon/titles tpch/p_name tpch/c_comment; do
  colargs+=(--column "$c=datasets/materialized/$c.col")
done
step() {
  local name=$1; shift
  echo "=== $name START $(date -Is)"; hw
  if PIN_CPUS=1 PYTHONPATH=. PYTHONHASHSEED=0 taskset -c 1 "$@"; then
    echo "=== $name OK $(date -Is)"
  else
    echo "=== $name FAILED $(date -Is)"
  fi
  hw
}
{
step headline $VPY -m orchestrator.orchestrate --build-root build \
     --cells build/headline_cells.yaml --modes experiments/baseline_modes.yaml \
     --needles testdata/g6_needles.txt --db $V/results.sqlite --csv $V/results.csv \
     --manifest $V/manifest.json --workdir $V/headline_workdir
step decode $VPY -m experiments.decode_driver "${colargs[@]}" \
     --workdir $V/decode --out-json $V/decode/results.json \
     --out-csv $V/decode/observations.csv
step dictorder $VPY -m experiments.dictionary_order_diagnostic_driver "${colargs[@]}" \
     --wire-root $V/decode --workdir $V/dictorder \
     --samples 11 --warmups 2
step access $VPY -m experiments.ra_headline_driver --skip repair \
     --db $V/ra_headline_results.sqlite
step a5 $VPY -m experiments.a5_driver --datasets-manifest experiments/datasets.yaml \
     --a5-cells experiments/a5_cells.yaml --columns-dir datasets/materialized \
     --db $V/a5_results.sqlite --build-root build
step a6 $VPY -m experiments.a6_driver --datasets-manifest experiments/datasets.yaml \
     --a6-cells experiments/a6_cells.yaml --columns-dir datasets/materialized \
     --db $V/a6_results.sqlite --build-root build
step a4 $VPY -m experiments.a4_driver --datasets-manifest experiments/datasets.yaml \
     --a4-cells experiments/a4_cells.yaml --columns-dir datasets/materialized \
     --db $V/a4_results.sqlite --runner-path build/runners/onpair/onpair_runner
# Re-Pair is cut short here (5 minutes per size); only OnPair's numbers matter
step scale $VPY -m experiments.nsweep_driver --db $V/nsweep_results.sqlite --op-timeout-s 300
} 2>&1 | tee -a pass3.log
echo "=== pass3 finished $(date -Is)" | tee -a pass3.log
